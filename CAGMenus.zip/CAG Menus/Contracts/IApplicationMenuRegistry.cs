﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Contracts
{
    public interface IApplicationMenuRegistry
    {
        void RegisterMenuItem(string menuItemName, string description, Type viewType);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Composite.Modularity;
using Contracts;
using ModuleA.Views;

namespace ModuleA
{
    public class ModuleA : IModule
    {
        #region IModule Members
        IApplicationMenuRegistry _menus;
        public ModuleA(IApplicationMenuRegistry registry)
        {
            _menus = registry;
        }

        public void Initialize()
        {
            _menus.RegisterMenuItem("Test Item 1", "This is a menu item. Also a test.", typeof(TestView1));
            _menus.RegisterMenuItem("Test Item 2", "This is another menu item. Test.", typeof(TestView2));
        }

        #endregion
    }
}

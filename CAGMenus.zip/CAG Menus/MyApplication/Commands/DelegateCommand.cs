﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Composite.Presentation.Commands;

namespace MaryKay.SamPortal.Modules
{
    /// <summary>
    /// Wrapper for DeletegateCommand<T>
    /// TODO this needs to be in a utility/library and not embedded in InformationBulletins
    /// </summary>
    public class DelegateCommand : DelegateCommand<object>
    {
        public DelegateCommand(Action<object> executeMethod, Func<object, bool> canExecuteMethod)
            : base(executeMethod, canExecuteMethod) { }

        public DelegateCommand(Action<object> executeMethod)
            : base(executeMethod) { }

        public DelegateCommand(Action executeMethod, Func<bool> canExecuteMethod)
            : base(parameter => executeMethod(), parameter => canExecuteMethod()) { }

        public DelegateCommand(Action executeMethod)
            : base(parameter => executeMethod()) { }
    }

}

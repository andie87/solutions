﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Contracts;
using Microsoft.Practices.Composite.Regions;
using Microsoft.Practices.Unity;
using System.Windows;

namespace MyApplication.Services
{
    public class ApplicationCommands : IApplicationCommands
    {
        #region IApplicationCommands Members

        IRegionManager _regions;
        IUnityContainer _container;
        public ApplicationCommands(IRegionManager rm, IUnityContainer container)
        {
            _regions = rm;
            _container = container;
        }

        public void CloseView(object view)
        {
            _regions.Regions["TabRegion"].Remove(view);
        }

        public void OpenView(string title, Type viewType)
        {
            UIElement controlToShow = _container.Resolve(viewType) as UIElement;
            OpenView(title, controlToShow);
        }

        public void OpenView(string title, System.Windows.UIElement viewToOpen)
        {
            _regions.AddToRegion("TabRegion", viewToOpen);
            _regions.Regions["TabRegion"].Activate(viewToOpen);
        }

        #endregion


    }
}

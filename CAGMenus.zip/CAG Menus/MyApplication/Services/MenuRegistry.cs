﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Contracts;
using MyApplication.ViewModels;
using Microsoft.Practices.Unity;

namespace MyApplication.Services
{
    public class MenuRegistry : IApplicationMenuRegistry
    {
        #region IApplicationMenuRegistry Members

        IUnityContainer _container;
        ShellViewModel _viewModel;

        public MenuRegistry(IUnityContainer container, ShellViewModel viewModel)
        {
            _container = container;
            _viewModel = viewModel;
        }

        public void RegisterMenuItem(string menuItemName, string description, Type viewType)
        {
            MenuItemViewModel vm = _container.Resolve<MenuItemViewModel>();
            vm.Name = menuItemName;
            vm.Description = description;
            vm.ViewType = viewType;
            _viewModel.MenuItems.Add(vm);

        }

        #endregion
    }
}

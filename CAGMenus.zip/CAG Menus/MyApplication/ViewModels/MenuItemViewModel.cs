﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MaryKay.SamPortal.Modules;
using Contracts;

namespace MyApplication.ViewModels
{
    public class MenuItemViewModel : ViewModel
    {
        private DelegateCommand _openCommand;
        public DelegateCommand OpenCommand
        {
            get { return _openCommand; }
            set
            {
                _openCommand = value;
                OnPropertyChanged("OpenCommand");
            }
        }



        private string _name;
        private string _description;
        private Type _viewType;
        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                OnPropertyChanged("Name");
            }
        }

        public string Description
        {
            get { return _description; }
            set
            {
                _description = value;
                OnPropertyChanged("Description");
            }
        }

        public Type ViewType
        {
            get { return _viewType; }
            set
            {
                _viewType = value;
                OnPropertyChanged("ViewType");
            }
        }

        public MenuItemViewModel(IApplicationCommands commands)
        {
            OpenCommand = new DelegateCommand(() =>
            {
                commands.OpenView(Name, ViewType);
            });


        }
    }
}

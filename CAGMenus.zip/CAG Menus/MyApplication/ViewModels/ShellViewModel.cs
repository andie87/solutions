﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Composite.Presentation.Commands;
using System.Collections.ObjectModel;
using Contracts;

namespace MyApplication.ViewModels
{
    public class ShellViewModel : ViewModel
    {
        private ObservableCollection<MenuItemViewModel> _menuItems = new ObservableCollection<MenuItemViewModel>();
        public ObservableCollection<MenuItemViewModel> MenuItems
        {
            get
            {
                return _menuItems;
            }
        }

        private DelegateCommand<object> _closeCommand;
        public DelegateCommand<object> CloseCommand
        {
            get { return _closeCommand; }
            set
            {
                _closeCommand = value;
                OnPropertyChanged("CloseCommand");
            }
        }

        IApplicationCommands _commands;
        public ShellViewModel(IApplicationCommands commands)
        {
            _commands = commands;
            CloseCommand = new DelegateCommand<object>(CloseDoc);
        }

        public void CloseDoc(object o)
        {
            _commands.CloseView(o);
        }



    }
}
